.. pymprog documentation master file, created by
   sphinx-quickstart on Thu May 21 09:19:35 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

PyMathProg: easy GLPK in Python!
================================

Welcome! **PyMathProg** is a *Python* reincarnation of
`AMPL <http://www.ampl.com/>`_ and 
`GNU MathProg <http://http://www.gnu.org/software/glpk/>`_
modeling language, implemented in pure Python, connecting to 
`GLPK <http://www.gnu.org/software/glpk/>`_
via `PyGLPK <http://www.cs.cornell.edu/~tomf/pyglpk/>`_. 
Create, optimize, report, change and re-optimize 
your model with Python, which offers numerous handy goodies.
Being embedded in Python, you can take advantage of the other 
good things available in python: such as easy database access, 
graphical presentation of your solution, statistical analysis, 
or use pymprog for artificial intelligence in games, etc.



.. raw:: html

   <p align=center> More PyMathProg resources at
   <a href="http://sourceforge.net/projects/pymprog/" target=_parent>
   <img src="http://sflogo.sourceforge.net/sflogo.php?group_id=259552&amp;type=11" 
   width="120" height="30" border="0" alt="SourceForge.net Logo" /></a></p>

Getting Help
------------

There are several ways to get some help:

#. Email list: https://lists.sourceforge.net/mailman/listinfo/pymprog-help

#. Project homepage: http://pymprog.sf.net/

#. Forum: https://sourceforge.net/forum/forum.php?forum_id=942151

Contents:
---------

.. toctree::
   :maxdepth: 2

   setup
   tutorial
   advanced
   vars
   indices
   constr
   solvopt
   subtour

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

