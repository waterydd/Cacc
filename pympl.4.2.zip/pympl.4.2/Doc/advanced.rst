.. A simple tutorial by Yingjie Lan, May 2009.

More Advanced Examples
=======================

Some of these examples were originally written in 
GNU MathProg by Andrew Makhorin (thanks, Andrew),
and were adopted into PyMathProg. 


#. :ref:`assign`
#. :ref:`dynaqueens`
#. :ref:`tsp`
#. :ref:`zebra`
#. :ref:`magic`
#. :ref:`sudoku`
#. :ref:`sudoku2`
#. :ref:`jobsched`
#. :ref:`revman`

.. _assign:

Re-optimize the assignment
--------------------------

In this example, we first solve the assignment problem,
then we change one of the cost parameter, and
re-optimize. See how easily this is done in PyMathProg.

.. literalinclude:: ../gassign.py
      :linenos:


.. _dynaqueens:

Interaction with queens
-----------------------

This example will ask to give a board size and then
you are given the opportunity to place some queens
on the board. The rest of the queens are then placed
by the program to maximize the total number of queens
that can be placed without attaching each other.

.. literalinclude:: ../dynaqueens.py
      :linenos:

.. _tsp:

The traveling sales man (TSP) problem
-------------------------------------

Really, the too well known problem.

.. literalinclude:: ../tsp.py
      :linenos:

.. _zebra:

Zebra: using string as index
----------------------------

A logic puzzle, see how strings are
used as indices here to enhance the
readability of the model.

.. literalinclude:: ../zebra.py
      :linenos:


.. _magic:

Magic numbers
--------------

Magic numbers, a very interesting problem.

.. literalinclude:: ../magic.py
      :linenos:

.. _sudoku:

Sudoku: want some AI?
---------------------

Do you play Sudoku? This program might help you crack a puzzle in seconds ;).

.. literalinclude:: ../sudoku.py
      :linenos:

.. _sudoku2:

Super Sudoku
------------

This example will provide a sample Super Sudoku:
in addition to satisfying all the requirements 
of Sudoku, Super Sudoku also requires that the
elements in each diagonal must be distinct,
below is a sample Super Sudoku obtained by the
code provided afterwards::

 +-------+-------+-------+
 | 2 1 3 | 4 6 5 | 8 7 9 |
 | 4 5 6 | 7 8 9 | 2 1 3 |
 | 7 8 9 | 2 1 3 | 4 5 6 |
 +-------+-------+-------+
 | 1 2 4 | 3 5 6 | 7 9 8 |
 | 3 6 8 | 9 7 2 | 5 4 1 |
 | 9 7 5 | 8 4 1 | 3 6 2 |
 +-------+-------+-------+
 | 8 4 2 | 1 9 7 | 6 3 5 |
 | 6 3 1 | 5 2 4 | 9 8 7 |
 | 5 9 7 | 6 3 8 | 1 2 4 |
 +-------+-------+-------+


.. literalinclude:: ../ssudoku.py
      :linenos:



.. _jobsched:


Machine Scheduling
------------------

Schedule jobs on a single machine, given the duration, 
earliest start time, and the latest finish time
of each job. Jobs can not be interrupted, and
the machine can only handle one job at one time. 

.. literalinclude:: ../sched_jobs.py
      :linenos:

The output schedule is as follows (your run
may not be the same, as the data is randomly
generated -- you might even get infeasible
problem instances)::

  Duration [7, 4, 1, 7]
  Earliest [13, 17, 19, 12]
  Latest [22, 41, 28, 38]
  status: opt
  schedule:
  job 0: 13.0 20.0
  job 1: 20.0 24.0
  job 2: 27.0 28.0
  job 3: 31.0 38.0


.. _revman:

Scheduling for Revenue
-----------------------

The same scheduling problem as above, but add a new
spin to the problem: when it is not feasible to 
accept all jobs, try accept those that will maximize
the total revenue.

.. literalinclude:: ../revman_jobs.py
      :linenos:

