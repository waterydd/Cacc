
Working with Solver Options
============================

When you need to set options with your solver,
pymprog package provides a global funciton 
*solvopt(...)* to do so. Actually, it does
more than that: you can use it to set, get,
or delete options, and retrieve all options
you have set so far as a diction. 
This function only accepts keyword arguments,
but can accept any "keyword=value" pair, 
and the meaning is up to the solver interface.


.. _setgetopt:

Setting and getting options
----------------------------

Here is how you set and check your options::

  >>> from pymprog import *
  >>> beginModel('test')
  >>> solvopt(method='exact', verbosity=2)
  >>> solvopt()
  {'verbosity': 2, 'method': 'exact'}

The sample above use the global function call 
to set the option *method* to 'exact', this
may mean that GLPK solver (the default solver)
will solve the problem by the exact method.
To retrieve all the options as a dict, simply
call *solvopt()* without any parameter. To change
one or more of the options, the syntax
is the same as setting an option. Let's continue
with that python session and try this::

  >>> solvopt(verbosity=0)
  >>> solvopt()['verbosity']
  0

Now you see that the *verbosity* option has been 
changed from 2 to 0.

.. _delopts:

Deleting an option
-------------------

To delete an option, simply set it to *None*. Now
continue with the python session::

  >>> solvopt(verbosity=None)
  >>> solvopt()
  {'method': 'exact'}

We saw that the *verbosity* option is deleted.

.. _simplex:
  
Special options for the simplex method
---------------------------------------

If you use the simplex method (this is the default method)
to solve your LP problem, the following options are available::

          keywds=("msg_lev", "meth", "pricing",
          "r_test", "tol_bnd", "tol_dj", "tol_piv",
          "obj_ll", "obj_ul", "it_lim", "tm_lim",
          "out_frq", "out_dly", "presolve")

These options are provided via pyglpk, and unfortunately
other LP methods do not have such options in pyglpk.
The details of these options are explained in pyglpk documentation::

    simplex(...): simplex([keyword arguments])
    
    Attempt to solve the problem using a simplex method.
    
    This procedure has a great number of optional keyword arguments
    to control the functioning of the solver.  We list these here,
    including descriptions of their legal values.
    
    msg_lev : Controls the message level of terminal output.
      LPX.MSG_OFF -- no output (default)
      LPX.MSG_ERR -- error and warning messages
      LPX.MSG_ON  -- normal output
      LPX.MSG_ALL -- full informational output
    meth    : Simplex method option
      LPX.PRIMAL  -- use two phase primal simplex (default)
      LPX.DUALP   -- use two phase dual simplex, primal if that fails
    pricing : Pricing technique
      LPX.PT_STD  -- standard textbook technique
      LPX.PT_PSE  -- projected steepest edge (default)
    r_test  : Ratio test technique
      LPX.RT_STD  -- standard textbook technique
      LPX.RT_HAR  -- Harris' two-pass ratio test (default)
    tol_bnd : Tolerance used to check if the basic solution is primal
      feasible. (default 1e-7)
    tol_dj  : Tolerance used to check if the basic solution is dual
      feasible. (default 1e-7)
    tol_piv : Tolerance used to choose pivotal elements of the simplex
      table. (default 1e-10)
    obj_ll  : Lower limit of the objective function.  The solver
      terminates upon reaching this level.  This is used only in
      dual simplex optimization. (default is min float)
    obj_ul  : Upper limit of the objective function.  The solver
      terminates upon reaching this level.  This is used only in
      dual simplex optimization. (default is max float)
    it_lim  : Simplex iteration limit. (default is max int)
    tm_lim  : Search time limit in milliseconds. (default is max int)
    out_frq : Terminal output frequency in iterations. (default 200)
    out_dly : Terminal output delay in milliseconds. (default 0)
    presolve: Use the LP presolver. (default False)
      dual simplex optimization. (default is max float)
    it_lim  : Simplex iteration limit. (default is max int)
    tm_lim  : Search time limit in milliseconds. (default is max int)
    out_frq : Terminal output frequency in iterations. (default 200)
    out_dly : Terminal output delay in milliseconds. (default 0)
    presolve: Use the LP presolver. (default False)

The constants involved are available in pymprog as is. For example, you
can set an option like this: solvopt(msg_lev=LPX.MSG_ERR), after you have
imported pymprog useing "from pymprog import \*" statement.

Note: if you need to warm start your simplex method 
(that is, start the simplex method with the optimal 
basis from your last invocation, which is often used 
when employing row generation and/or column generation), please don't turn on the 'presolve' option. If your
row/column generation algorithm is computation 
intensive and you need to write them in C and invoke
from Python, you can consider EXPY (http://expy.sf.net),
ctypes, SWIG (Sip for C++), and Boost.Python. 

.. _integer:

Special options for the integer method
---------------------------------------

When you use the integer(...) method in pyglpk to
solve your MIP problem (this is the default method), 
you may use the following options::

          keywds=("msg_lev", "br_tech", "bt_tech",
          "pp_tech", "gmi_cuts", "mir_cuts",
          "tol_int", "tol_obj", "tm_lim", "out_frq",
          "out_dly", "callback")

Note that if your glpk version is too old (older than 4.24),
some options might not be supported. Also, it seems that 
pyglpk does not support options for other MIP methods.
The details of these options are explained in pyglpk documentation::

   integer(...)

          MIP solver based on branch-and-bound.

          This procedure has a great number of optional keyword arguments
          to control the functioning of the solver.  We list these here,
          including descriptions of their legal values.

          msg_lev : Controls the message level of terminal output::

            LPX.MSG_OFF -- no output (default)
            LPX.MSG_ERR -- error and warning messages
            LPX.MSG_ON  -- normal output
            LPX.MSG_ALL -- full informational output

          br_tech : Branching technique option::

            LPX.BR_FFV  -- first fractional variable
            LPX.BR_LFV  -- last fractional variable
            LPX.BR_MFV  -- most fractional variable
            LPX.BR_DTH  -- heuristic by Driebeck and Tomlin (default)

          bt_tech : Backtracking technique option::

            LPX.BT_DFS  -- depth first search
            LPX.BT_BFS  -- breadth first search
            LPX.BT_BLB  -- best local bound (default)
            LPX.BT_BPH  -- best projection heuristic

          pp_tech : Preprocessing technique option::

            LPX.PP_NONE -- disable preprocessing
            LPX.PP_ROOT -- perform preprocessing only on the root level
            LPX.PP_ALL  -- perform preprocessing on all levels (default)

          gmi_cuts: Use Gomory's mixed integer cuts (default False)

          mir_cuts: Use mixed integer rounding cuts (default False)

          tol_int : Tolerance used to check if the optimal solution to the
            current LP relaxation is integer feasible.

          tol_obj : Tolerance used to check if the objective value in the
            optimal solution to the current LP is not better than the best
            known integer feasible solution.

          tm_lim  : Search time limit in milliseconds. (default is max int)

          out_frq : Terminal output frequency in milliseconds. (default 5000)

          out_dly : Terminal output delay in milliseconds. (default 10000)

          callback: A callback object the user may use to monitor and control
            the solver.  During certain portions of the optimization, the
            solver will call methods of callback object. (default None)

          The last parameter, callback, is worth its own discussion.  During
          the branch-and-cut algorithm of the MIP solver, at various points
          callback hooks are invoked which allow the user code to influence
          the proceeding of the MIP solver.  The user code may influence the
          solver in the hook by modifying and operating on a Tree instance
          passed to the hook.  These hooks have various codes, which we list
          here::

              select - request for subproblem selection
              prepro - request for preprocessing
              rowgen - request for row generation
              heur   - request for heuristic solution
              cutgen - request for cut generation
              branch - request for branching
              bingo  - better integer solution found

          During the invocation of a hook with a particular code, the
          callback object will have a method of the same name as the hook
          code called, with the Tree instance.  For instance, for the
          'cutgen' hook, it is equivalent to: callback.cutgen(tree),
          being called with tree as the Tree instance.  If the method does
          not exist, then instead the method 'default' is called with the
          same signature.  If neither the named hook method nor the default
          method exist, then the hook is ignored.

The constants involved are available in pymprog as is. For example, you
can set an option like this: solvopt(br_tech=LPX.BR_FFV), after you have
imported pymprog useing "from pymprog import \*" statement.

.. _modinsopt:

Options with a model instance
------------------------------

Options can be also set with a model instance, 
which has the same method *solvopt(...)* as the
global function *solvopt(...)*. In fact, the
global function delegates all the work to that
method of the hidden model instance.
