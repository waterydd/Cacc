from pymprog import *

beginModel()

x = var()
minimize(x)
r=st(+x>=5)

solve()
print status()

print r.dual

endModel()
