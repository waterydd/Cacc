from pymprog import *

def testBinder():
   binder = iprod(('a','b'),range(3))
   print len(binder)
   vd = {}
   for t in binder: 
     vd[t] = t
   for t in binder: print vd[t]


testBinder()

def testProblem():
  p = model('test')
  x = p.var(range(3), 'x')
  for i in range(3): print x[i] <= 5
  inds = iprod(range(3), range(2))
  y = p.var(inds, 'y')
  for t in inds: print 1 <= y[t] <= 3
  for v in p.p.cols: print v.name, v.bounds,
  print
  #ex = (-x[0] + 2* x[1] - 5*y[2,1])*3 + 23
  #print ex
  #print (10 <= ex <= 30)
  #p.st(20 <= ex <= 60)
  for i in range(3): print x[i].name, x[i].bounds,
  print "End"
  #del ex
  #del p.p
  #del p

testProblem()

import gc
gc.collect()
print gc.garbage
