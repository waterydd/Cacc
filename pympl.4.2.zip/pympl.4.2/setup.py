from distutils.core import setup, Extension
import sys, os, os.path

#This setup file is provided by Yingjie Lan <ylan@umd.edu>
#to faciliate the installation of PyMathProg.

ld = """PyMathProg is a Python reincarnation of AMPL and 
GNU MathProg modeling language, implemented in pure Python, 
connecting to GLPK via PyGLPK. Create, optimize, report, 
change and re-optimize your model with Python, 
which offers numerous handy goodies."""

setup(name = 'pymprog',
      version = '0.4.2',
      description = 'PyMathProg, easy linear/integer programming with Python.',
      long_description = ld,
      author = 'Yingjie Lan',
      author_email = 'ylan@umd.edu',
      url = 'http://pymprog.sf.net/',
      license = 'GPL',
      classifiers = [
    'Development Status :: 4 - Beta',
    'Intended Audience :: Science/Research',
    'License :: OSI Approved :: GNU General Public License (GPL)',
    'Programming Language :: Python',
    'Operating System :: Platform Independent',
    'Topic :: Scientific/Engineering :: Mathematics',
    'Topic :: Software Development :: Libraries :: Python Modules' ],
      py_modules=['pymprog']
)

#This setup file is provided by Yingjie Lan <ylan@umd.edu>
#to faciliate the installation of PyGLPK for windows.
#source code has also been slightly tweaked,
# and this version is PyGLPK 0.3.3
#To build a binary distribution for windows:
#python setup.py bdist_wininst

"""Thanks a lot to the following information and the providers:
http://wiki.python.org/moin/PyrexOnWindows
http://sebsauvage.net/python/mingw.html
http://www.develer.com/oss/GccWinBinaries
Also, to get pyglpk compile with minGW gcc,
I googled this:
"initializer element is not constant" "PyObject_GenericGetAttr"
to get things fixed.
"""

if sys.version[0:3] < '2.5': #ensure minGW support
    raise RuntimeError, ("The PyGLPK require Python 2.5 or later.")

sources = 'glpk lp barcol bar obj util kkt tree environment'
source_roots = sources.split()

# This build process will not work with anything prior to GLPK 4.16,
# since there were many notable changes in GLPK including,
# importantly, something which actually contains the version number.

# USERS DO CUSTOM INSTRUCTIONS HERE
# Perhaps set your libdir manually in case neither system defaults,
# nor the cleverness does not work.
libdirs, incdirs, extraobs = [], [], []

libs = ['glpk'] #omit 'gmp' -- not needed.
if sys.platform == 'win32':
   libdirs = ['C:\\Program Files\\GnuWin32\\bin']
   incdirs = ['C:\\Program Files\\GnuWin32\\include']
if sys.platform == 'darwin': # Mac OS X
   libdirs = ['/opt/local/lib']
   incdirs = ['/opt/local/include']

macros = []

# Now, finally, define that module!
module1 = Extension(
    'glpk',
    sources = [os.path.join('pyglpk/src',r+'.c') for r in source_roots],
    define_macros = macros,
    library_dirs = libdirs, include_dirs = incdirs,
    libraries = libs, extra_objects = extraobs)

ld = """The PyGLPK module gives one access to the functionality
of the GNU Linear Programming Kit.  
"""

setup(name = 'glpk',
      version = '0.3.3',
      description = 'PyGLPK, a Python module encapsulating GLPK.',
      long_description = ld,
      author = 'Thomas Finley, Yingjie Lan',
      author_email = 'tomf@cs.cornell.edu, ylan@umd.edu',
      url = 'http://www.cs.cornell.edu/~tomf/pyglpk/',
      license = 'GPL',
      classifiers = [
    'Development Status :: 3 - Alpha',
    'Intended Audience :: Science/Research',
    'License :: OSI Approved :: GNU General Public License (GPL)',
    'Programming Language :: C',
    'Programming Language :: Python',
    'Operating System :: POSIX',
    'Operating System :: MacOS :: MacOS X',
    'Topic :: Scientific/Engineering :: Mathematics',
    'Topic :: Software Development :: Libraries :: Python Modules' ],
      ext_modules = [module1])
