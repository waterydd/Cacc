#!/bin/bash
tar -czvf $1 *py capdist.csv README COPYING.txt ChangeLog maketgz.sh zipdist.sh Doc/*py Doc/*rst Doc/*bat Doc/Makefile html/*html html/_static/*png html/_static/*css html/_static/*js html/_sources/*txt pyglpk
