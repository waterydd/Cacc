from pymprog import *
xid = xrange(3)
beginModel()
x = var(xid)
k = par(xid)
for i in xid: 
  x[i] <= k[i]
  print x[i].bounds
c = st([x[i] for i in xid]) #convert to constraints
for i in xid: 
  print c[i]
  print repr(c[i])
endModel()
