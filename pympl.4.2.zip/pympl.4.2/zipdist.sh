#!/bin/bash
zip -r $1 *py capdist.csv README ChangeLog COPYING.txt maketgz.sh zipdist.sh Doc/*py Doc/*rst Doc/*bat Doc/Makefile html/*html html/_static/*png html/_static/*css html/_static/*js html/_sources/*txt pyglpk -x "*/.svn/*"
