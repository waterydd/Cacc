clear;  

sum1= textread('b.txt','%d');
max1 = textread('a.txt','%d');


range_x=2:1:8
figure  
    % ---------- Format of figure:  
    TextFontSize=18;  
    LegendFontSize = 16;  
    set(0,'DefaultAxesFontName','Times',...  
        'DefaultLineLineWidth',2,...  
        'DefaultLineMarkerSize',8);  
    set(gca,'FontName','Times New Roman','FontSize',TextFontSize);  
    %set(gcf,'Units','inches','Position',[0 0 6.0 4.0]);  
    % ---------- Format of figure:~   
   
  for i=1:1:2
      if (i==1)   h1 = plot( range_x, sum1, '--r' );
      elseif (i==2) h2 = plot( range_x, max1, '-g' );
   end
   hold on
  end
   % --------- Set the other formats of the figure :  
    grid off  
    axis([2 8 0 1000])  
    ylabel('fraction of topologies(miles)')  
    xlabel('number of root controllers')  
      
    % --------- Plot the multi-legends :  
   
  
    ah1 = axes('position',get(gca,'position'), 'visible','off');    
   
    hg2 = legend(ah1, [h1,h2],  'CCPP','CMCPP',  0);  
	set(gcf,'color','w');
    set(hg2,'FontSize',LegendFontSize);  
    % --------- Plot the multi-legends :~  
% --------- Set the other formats of the figure :~  