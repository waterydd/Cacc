Working with Constraints
========================

Defining constraints in PyMathProg is very easy. After started the model,
you can use the *st(.)* method to add constraints. You simply use 
natural ways to construct your constraint expression (please see
some of the advanced examples). 

#. :ref:`single`
#. :ref:`double`
#. :ref:`wrong`
#. :ref:`sidef`
#. :ref:`summary`

.. _single:

With a single comparison
----------------------------

We can always use one comparison between two terms::

  beginModel()
  xid = xrange(3)
  x = var(xid)
  y = var()
  p = par([6,4,3])
  st( sum(x[i]*p[i] for i in xid) <= y )
  st( x[0] + x[2] >= x[1] )
  st( x[0] + x[2] <= 1 )

Those are perfectly fine: when there is only one comparison,
there is little limit on what you can do. 

.. _double:

With double comparisons
----------------------------

We can also use two consecutive comparisons to set lower and upper
bound on an expression simultaneously::

  st( 1 <= y <= 5)
  st( p[0]**2 <= y+x[0] <= p[1]*p[2] )

The first one use two constant values to set the bounds
simultaneously. The second one uses expressions of 
parameters as bounds (so that the bounds would be
automatically updated if the parameters change their values). 
They are both fine. An extra note on the first one: the 
first one also sets bounds on the *y* variable. That
is fine as long as that does not override some tighter bounds
that you have set on it before and you need to keep. Thus,
it is recommended that you set bounds on variables *after*
you have defined that kind of constraints, which does not
affect the bounds of constraints in any way.

.. _wrong:

Ill-formed constraints
-----------------------

More than two consecutive comparisons are not proper for
PyMathProg, although Python still allows that.
Another kind of ill-formed comparisons is a little
more subtle: with double comparisons, the
first or the last must be constants (that is, must
not involve any variables). Still a third type of
ill-formed constraints is when you use different
kind of comparison (<=, >=, ==) in a double
comparison.
Here are some examples of ill-formed constraints::

  st(0 <= x[1] + y <= 1 <= x[2]) #former parts lost
  st(y+x[0] <= x[2] <= 3) #former parts lost
  st(0 <= y+x[0] <= x[2]) #how do you interprete it?
  st(0 <= y+x[0] => -1) #not very smart, eh?

Those are bad examples, the reasons should be obvious.

.. _sidef:

A special case
---------------

It is OK to use the st(.) call to set a constraint
like this: st( A <= x <= B), where A and B are 
two constants (expressions of numbers or 
param instances). This first sets the bounds of x
to A and B, then the variable x is passed to st(.), 
then st(.) converts it into an expression '+x', and
then use the bounds on x to construct the constraint,
So be ware of the side effect: 

(1) the bounds on x changed and more subtly, 

(2) the constraint is surely redundant as the
    bounds on x effectly ensures the same thing.

To ensure your variable bounds won't be modified 
by such constraints, it is recommended to set 
variable bounds after all constraints. 
Or, you can equivalently 
write: st(A <= +x <= B) or st(0 <= x - A <= B-A). 
Similarly, st(A <= x) can be replaced by 
st(A <= +x) or st(0 <= x - A). That way 
the variable x is not exposed, rather an
expression +x (which is not the same as x)
is used to construct the constraint.

.. _summary:

Conclusion
------------

PyMathProg provides much flexibility in constructing
constraints. We should avoid some ill-formed constraints.
With double comparisons, the first and the last expression 
must not involve variables, and we should use the same kind
of comparison.

