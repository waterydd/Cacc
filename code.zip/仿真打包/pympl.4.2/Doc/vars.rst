Working with variables
======================

#. :ref:`create`
#. :ref:`bounds`

.. _create:

Creating variables
--------------------

Creating variables in PyMathProg is easy.
You can create a single variable, or a group
of variables at once. You will use the
*var(...)* method to create variables::

  x = var()
  y = var(kind=bool)
  z = var(xrange(3), 'Z', int)
  w = var(xrange(3), 'W'', bounds=(0,5))

In the above codes, *x, y* are two single variables,
*x* is continuous, *y* is binary. *z, w* are created
over an index set *xrange(3)*, which is *{0,1,2}*.
So, you have actually created a group of variables 
*z[0], z[1], z[3]*, and *w* is also a group. 
The *z* group are integer variables. Since *x,y,z*
no bounds are specified, they are default to *(0, None)*,
where *None* means no bound, so it is equivalent to infinity.
For *w*, the bounds are explicitly set to *[0,5]*.

.. _bounds:

Setting bounds to variables
----------------------------

Once you have created variables, and want to explicitly set
bounds on any variable, it is qutie straight forward in PyMathProg::

  x <= 20
  1 <= y <= 5
  b = [5, 8, 3]
  for i in xrange(3): z[i] <= b[i]
  None <= y

The first line above sets the upper bound of *x*, while the second
also provided the lower bound. The fourth one sets different upper
bounds on the group of *z* variables. The last one sets the lower bound of *y* to *None*, which means that there
is no lower bound (boundless).

Now, you can also use parameters for bounds, so that when the
parameters change in values, the bounds get updated automatically
when you resolve your problem::

  >>> from pymprog import *
  >>> beginModel()
  >>> p = par(3)
  >>> x = var()
  >>> x <= p*p
  X0=0.000000, idx:0
  >>> x.bounds
  (0.0, 9.0)
  >>> p.value = 4
  >>> param.updateAll()
  set([X0=0.000000, idx:0])
  >>> x.bounds
  (0.0, 16.0)

You use the *param.updateAll()* call to actively request an update
of all the variable and constraints that depends on parameter values.


