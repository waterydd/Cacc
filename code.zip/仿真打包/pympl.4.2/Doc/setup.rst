.. A simple tutorial by Yingjie Lan, May 2009.

How to Setup PyMathProg
=======================

Here are some guides on how to setup your
environment to run PyMathProg, choose
your platform:

#. :ref:`wind-setup`.
#. :ref:`linux-setup`.
#. :ref:`mac-setup`.

.. _wind-setup:

How to setup on Windows
-----------------------

The easy way:
^^^^^^^^^^^^^

#. Setup Python 2.5.4. 

#. Install GLPK: a setup program can be downloaded
   `here <http://gnuwin32.sourceforge.net/packages/glpk.htm>`_ 
   and make sure your PATH enviroment variable
   contains the path to the glpk.dll file
   (by default in english language, it is in folder
   "C:\\Program Files\\GnuWin32\\bin").

#. Download dist#.#.zip (where #.# is the version)
   and unzip it, you will find two windows installer,
   and a zip file containing the source files.
   Run both installers. Unzip the source files and 
   you can now play with the examples there. 

The hard way:
^^^^^^^^^^^^^

#. If you would like to complile pyglpk yourself: 
   Setup Python 2.5.4 and MinGW 5.1.6 
   (MinGW has gcc compiler -- the minimal 
   installation should work. I tried to work with the 
   C compiler from Microsoft Visual Studio C++, 
   but failed to compile PyGLPK, this is why
   I avoided Python 2.6, as some versions will use 
   the Microsoft C compiler).

#. Install GLPK: a setup program can be downloaded
   `here <http://gnuwin32.sourceforge.net/packages/glpk.htm>`_ and when you
   install, make sure you install it in the "C:\\Program Files\\GnuWin32" 
   folder. If you installed it somewhere else, you have to modify the 'setup.py' 
   file to change the hardcoded installation directory of GLPK.
#. Make sure your %PATH% environment variable
   contains "C:\\Python25;C:\\MinGW\\bin;C:\\Program Files\\GnuWin32\\bin", 
   assuming you have installed them that way (the default).
#. Install PyGLPK (skip this step if pymprog version >= 0.3.0): 
   unzip the source code of pyglpk (please goto the download
   section of `pymprog <https://sourceforge.net/projects/pymprog/>`_
   project page at source forge -- other sources might not compile on windows),
   go to the top folder that contains the setup.py file, issue this command::

      python setup.py build --compiler=mingw32 install

   to have it installed.
#. Also download the source code for pymprog, unzip it and open a command 
   window (click Start->Run->type in 'cmd') 
   and change to the unzipped folder, run::

      python setup.py build --compiler=mingw32 install

   Note: the compiler from the freely available 
   `Microsoft Visual C++ 2008 Express Edition 
   <http://www.microsoft.com/express/download/#webInstall>`_
   is not recommended.

   If you would like to build a binary distribution, issue this command::

      python setup.py build --compiler=mingw32 bdist_wininst

   Then the distribution files (binary installers) 
   are stored in the 'dist' folder

.. _linux-setup:

How to setup on Linux
---------------------

#. Setup Python 2.4 or later.
#. Install GLPK. For more information, visit
   `GLPK homepage <http://www.gnu.org/software/glpk/>`_.
#. Install PyGLPK (skip this step if pymprog version >= 0.3.0): 
   unzip the source code of pyglpk (please goto the download
   section of `pymprog <https://sourceforge.net/projects/pymprog/>`_
   project page at source forge -- other sources might not compile on windows),
   go to the top folder that contains the setup.py file, issue this command::
     
      python setup.py install

   to have it installed.
#. Also download the source code for pymprog, unzip it and start playing with
   the examples. If you wish, you can also install it, by running::

      ~/pymprog$ python setup.py install

   once you have changed to the folder you have unzipped pymprog into.

.. _mac-setup:


How to setup on Mac OS X
------------------------

#. Setup Python 2.4 or later (Mac has that by default, so you should need to do nothing).
#. Setup glpk. Make sure you have the right version of xcode and MacPort for your 
   version of Mac OS (download the right dmg files, and follow the installation steps), 
   then type this in a terminal::

      sudo port install glpk

   and that should install glpk onto your system.
#. Download pymprog0.3.1 or later, unzip and change to the base folder::

      sudo python setup.py install

   and that's it.
