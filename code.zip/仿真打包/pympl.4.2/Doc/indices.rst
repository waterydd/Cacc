
Working with Indices
======================

Without index sets, it is really hard to work with big models:
one has to give each variable a different name, it soon 
becomes difficult to remember or understand. In modern
modeling languages such as AMPL and GMPL, index sets 
are an essential building block, which is really not
surprising, as we see indices almost everywhere in advanced
mathematics. PyMathProg also provides an elegant solution
to indexing into variables and constraints.


#. :ref:`natural`
#. :ref:`combined`
#. :ref:`varndx`
#. :ref:`parndx`


.. _natural:

Natural indices
----------------

Python already provides some natural indices: 
tuples, lists, sets, or anything iterable 
(e.g. you can use a generator, a sequence, etc.).
PyMathProg does not check if you have identical items
in there, you must check that for yourself, or you
can allow repeated elements (such as in a multiset).
PyMathProg trusts you to provide a list or a tuple
or any iterable as a good set without repeated elements.
They can be utilized in PyMathProg as indices
for variables, constraints, and parameters.

.. _combined:

Combined indices
----------------

PyMathProg also provides a way to combine smaller index sets
into bigger ones by the concept of set product. Given two sets
A and B, the product of A * B is defined as::

   A * B = { (a,b) : a in A, b in B }

In the pymprog module, there is a class to achieve this::

  >>> from pymprog import *
  >>> A = (1, 2, 3)
  >>> B = (6, 7, 8)
  >>> C = iprod(A,B)
  >>> for c in C: print c,
  ... 
  (1, 6) (1, 7) (1, 8) (2, 6) (2, 7) (2, 8) (3, 6) (3, 7) (3, 8)

Well, that's about it. By the way, the constructor *iprod(...)* 
can take as many iterables (sets, lists, tuples, or sequences) 
as you want -- that's the cool part of it.


.. _varndx:


Use index with variables
-------------------------

It is very simple to create many variables over some indices with PyMathProg.
Let's continue the python session above::

  >>> beginModel('test')
  >>> x = var(C, 'X')
  >>> type(x)
  <type 'dict'>
  >>> x[2,7].name
  'X[(2, 7)]'

So we start a model named 'test' first. Then we use the combined set C as 
the index set to create variables, the major variable name is 'X'. 
Our of curiosity, we want to know the type of the python object 
referenced by 'x': it turns out to be a dict type -- probably that 
is not that important anyway, what is more important is how we can index it, 
as shown by the next line of python command.


.. _parndx:

Use index with parameters
--------------------------

It is again very simple to create parameters. Notice if your parameters
are not supposed to change in your program, you really don't need them:
the major purpose of using parameters is to be able to change them
and observe how that affects the optimal solution. When you call the 
solve() method/function, changed parameters are automatically take
into consideration by PyMathProg to update the model. Let's continue
our python session::

  >>> a = par([3.14, 2.73, 1.41], 'A')
  >>> type(a)
  <type 'list'>
  >>> a[0].name, a[0].value
  ('A[0]', 3.1400000000000001)

There is one important property of parameter creation: the original indexing
of the raw values you passed in remains unchanged for the created parameters.
Let's continue with the live illustration::

  >>> pv = {'east':0, 'west':2, 'south':3, 'north':1}
  >>> pp = par(pv, 'P')
  >>> pp['west'].value == pv['west']
  True
  >>> pp['west'].name
  'P[west]'

The cool thing about it is that this can be recursive::

  >>> rec = [{(3,4):3.14, (1,2):4.5}, 50]
  >>> pec = par(rec, 'R')
  >>> rec[0][3,4]
  3.1400000000000001
  >>> pec[0][3,4].value
  3.1400000000000001
  >>> rec[1] == pec[1].value
  True

Folks, that's pretty much there is to it! 
