#parameters
n = 32 #number of cities
D = None #distance matrix, D[i,i] = infty
MD = None #max relief distance
A = None #number of aux reliefs
AD = None #radius of aux reliefs
R = None #typical relief demand
AR = None #minimum aux relief capacity
M = None #maximum relief ability
F = None #fixed cost
C = None #variable cost
#index sets
N = xrange(n) #city index
#no city can provide relief for itself
K = [(i,j) for i in N for j in N if i!=j]

from pymprog import *

#choose city i iff x[i]==1
x = var(N, 'x', bool)
#relief capacity
v = var(N, 'v')
#city i provides for j iff y[i,j] == 1
y = var(K, 'y', bool)

#total cost
minimize(sum( F[i]*x[i] + C[i]*v[i] for i in N), 'cost')

#a relief center must have enough capacity
#only one disaster at a time 
st(v[i] >= R[j]*y[i,j] for i,j in K)

#can provide relief capacity only if chosen
st(M[i]*x[i] >= v[i] for i in N)

#a city has only one primary relief city
st(sum(y[i,j] for i in N if i!=j) == 1 for j in N)

#the primary relief city must lie within a certain distance
st(sum(y[i,j]*D[i,j] for i in N if i!=j) <= MD[j] for j in N)

#aux relief cities: robust -- in case of huge disaster
st(sum(x[i] for i in N if D[i,j] <= AD[j]) >= 1+A[j] 
        for j in N if A[j]>0)

#aux relief cities: robust -- in case of huge disaster
st(sum(v[i] for i in N if D[i,j] <= AD[j]) >= R[j]+AR[j] 
        for j in N if A[j]>0)
