n = 3
N = range(n)
M = [(i,j) for i in N for j in N if i<j]

D = (3,4,2) #duration of each job
L = (0,2,0) #earliest start
U = (9,7,8) #latest finish

from pymprog import *

beginModel("job-scheduling")
x = var( N, "x" ) #start time
#MD[i,j] = (D[i]+D[j])/2.0
#T[i] = x[i] + D[i]
#y[i,j]<= |T[i]-x[j]-MD[i,j]|
#y[i,j] < MD[i,j] <==> overlap betw jobs i,j
y = var( M, "y" ) 
#w[i,j]: the 'OR' for |T[i]-x[j]-MD[i,j]|
w = var( M, "w", kind=bool)
# z[i,j] >= MD[i,j] - y[i,j]
z = var( M, "z")

minimize( sum(z[i,j] for i,j in M) )

st([(D[i]+D[j])/2.0 - (x[i]+D[i] - x[j]) + 
   (U[i]-L[j]) * w[i,j] >= y[i,j]
   for i,j in M], 'small')
st([(x[i]+D[i] - x[j]) - (D[i]+D[j])/2.0 +
   (U[j]-L[i])*(1-w[i,j]) >= y[i,j]
   for i,j in M], 'large')
st([(D[i]+D[j])/2.0 - y[i,j] <= z[i,j] 
   for i,j in M], 'overlap') 

#set bounds on x
for i in N:
   L[i] <= x[i] <= U[i] - D[i] 

#another way to enforce no overlapping:
#
# x[i] >= T[j] or x[j] >= T[i]
#
# Which can be formulated as:
#
# x[i] + (U[j]-L[i])*w[i,j]>= x[j]+D[j]
# x[j] + (U[i]-L[j])*(1-w[i,j]) >= x[i]+D[i]

solve()

print "status:", status()
print "overlap:", vobj()
print "schedule:"
for i in N:
   start = x[i].primal
   print "job %i:"%i, start, start+D[i]

