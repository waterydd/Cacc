# SUDOKU, Number Placement Puzzle 
# Written in pymprog by Yingjie Lan <ylan@umd.edu>

"""Sudoku, also known as Number Place, is a logic-based placement
   puzzle. The aim of the canonical puzzle is to enter a numerical
   digit from 1 through 9 in each cell of a 9x9 grid made up of 3x3
   subgrids (called "regions"), starting with various digits given in
   some cells (the "givens"). Each row, column, and region must contain
   only one instance of each numeral.

   (From Wikipedia, the free encyclopedia.)

   This example will provide a sample Super Sudoku:
   in addition to satisfying all the requirements 
   of Sudoku, Super Sudoku also requires that the
   elements in each diagonal must be distinct."""

from pymprog import *        # Import the module
beginModel("ssudoku")
I = xrange(1,10)
J = xrange(1,10)
K = xrange(1,10)
T = iprod(I,J,K) #create Indice tuples
#x[i,j,k] = 1 means cell [i,j] is assigned number k 
x = var(T, 'x', bool) #binary vars
#each cell must be assigned exactly one number
st([sum(x[i,j,k] for k in K)==1 for i in I for j in J], 'cell')
#cells in the same row must be assigned distinct numbers
st([sum(x[i,j,k] for j in J)==1 for i in I for k in K], 'row') 
#cells in the same column must be assigned distinct numbers
st([sum(x[i,j,k] for i in I)==1 for j in J for k in K], 'col')
#cells in the same region must be assigned distinct numbers
st([sum(x[i,j,k] for i in range(r,r+3) for j in range(c, c+3))==1
 for r in range(1,10,3) for c in range(1,10,3) for k in K],'reg')

#cells in \-diagonal
st([sum(x[i,i,k] for i in I)==1 for k in K])

#cells in /-diagonal
st([sum(x[i,10-i,k] for i in I)==1 for k in K])

#there is no need for an objective function here

solvopt(integer='advanced') #use advanced B&B
solve()

for i in I:
   if i in range(1,10,3):
      print " +-------+-------+-------+"
   print '',
   for j in J:
      if j in range(1,10,3): print "|",
      print "%g"%sum(x[i,j,k].primal*k for k in K),
      if j==9: print "|"
   if i == 9:
      print " +-------+-------+-------+"

