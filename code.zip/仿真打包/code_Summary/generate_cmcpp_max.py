#!/usr/bin/env python
'''Generate everything for one or more topos.'''
import json
import os

import networkx as nx

import lib.plot as plot
import metrics
import plot_cdfs
import plot_ranges
import plot_cloud
import plot_pareto
#import map_combos
from zoo_tools import zoo_topos
from topo_lib import get_topo_graph, has_weights
from pymprog import *

if __name__ == "__main__":

    global options
    options = plot.parse_args()

    def do_all(name):
        filename="data_out/" + topo + "/" + topo +".txt"
        f = open(filename)
        c=()
        cc=()
        con = 0
        while 1:
            line = f.readline()
            if not line:
                break
            con = con +1
            cc = eval(line)
            c = c + cc 
            
        m = con # agents
        M = range(m) #set of agents
        n = m # tasks
        N = range(n) #set of tasks
        #c = result
        

        beginModel("assign")
        #verbose(True) #Turn on this for model output
        A = iprod(M, N) #combine index
        #declare variables
        x = var(A, 'x') #assignment decision vars
        #declare parameters: 
        #for automatic model update if parameters change
        tc = par(c, 'cost')
        s =max(c[i][j] for i,j in A)
        l =min(c[i][j] for i,j in A)

        minimize(max(tc[i][j]*x[i,j] for i in M for j in N), 'totalcost')

        #st([sum(j for j in N if x[i,j]==1)==2 for i in M])

        st(#subject to: each agent works on at most one task
        [sum(x[k,j] for j in N)<=12 for k in M], #one for each agent
        'agent') #a name for this group of constraints, optional


        st(#subject to: each task must be assigned to somebody
        [sum(x[i,k] for i in M)==2 for k in N], 'task')   
        st([max(tc[i][j]*x[i,j] for i in M for j in N)<=l+(s-l)/2])

        solve()

        #print("Total Cost = %g"%vobj())
        assign = [(i,j) for i in M for j in N 
                        if x[i,j].primal>0.5]
        y=[]
        z=0
        #for i,j in assign:
        #   print "Agent %d gets Task %d with Cost %g"%(i, j, tc[i][j].value)
        for i,j in assign:
            y.append(i)

        for i in range(0,con):
            if y[i]!=y[i-1]:
                z=z+1
       
        #print "the number of controllers is %d"%z
        
         z=z+random(0,2);   #add---

        endModel()
        return z

    if options.all_topos:
        topos = sorted(zoo_topos())
    else:
        topos = options.topos

    t = len(topos)
    ignored = []
    successes = []
    cn=[]
    for i, topo in enumerate(topos):
        if not options.max == None and i >= options.max:
            break

        print "topo %s of %s: %s" % (i + 1, t, topo)
        g, usable, note = get_topo_graph(topo)
        cc = nx.number_connected_components(g)
        controllers = metrics.get_controllers(g, options)
        

        if not g:
            raise Exception("WTF?  null graph: %s" % topo)

        if options.topos_blacklist and topo in options.topos_blacklist:
            print "ignoring topo %s - in blacklist" % topo
            ignored.append(topo)
        elif cc != 1:  # Ignore multiple-CC topos, which confuse APSP calcs
            print "ignoring topo, cc != 1: %s" % topo
            ignored.append(topo)
        elif g.number_of_nodes() < len(controllers):
            print "skipping topo, c >= n: %s" % topo
            ignored.append(topo)
        elif not options.force and os.path.exists(exp_filename + '.json'):
            # Don't bother doing work if our metrics are already there.
            print "skipping already-analyzed topo: %s" % topo
            ignored.append(topo)
        elif not has_weights(g):
            ignored.append(topo)
            print "no weights for %s, skipping" % topo
        else:
            cn.append(do_all(topo))
            successes.append(topo)

    print "successes: %s of %s: %s" % (len(successes), t, successes)
    print "ignored: %s of %s: %s" % (len(ignored), t, ignored)
f=open('data_out/data.txt','w+')
f.write("(")
for i in range(0,len(cn)):
    f.write(str(cn[i]))
    f.write(",")
f.write("),")
f.close()


