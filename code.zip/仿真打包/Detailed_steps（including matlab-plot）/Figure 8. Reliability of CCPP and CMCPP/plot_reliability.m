num = xlsread('x.xls');
range_x=1:1:17;
y2=num(1,:);
y3=num(2,:);
figure  
    % ---------- Format of figure:  
    TextFontSize=18;  
    LegendFontSize = 16;  
    set(0,'DefaultAxesFontName','Times',...  
        'DefaultLineLineWidth',2,...  
        'DefaultLineMarkerSize',8);  
    set(gca,'FontName','Times New Roman','FontSize',TextFontSize);  
    set(gcf,'Units','inches','Position',[0 0 6.0 4.0]);  
    % ---------- Format of figure:~   

for i=1:1:2
   if (i==1)   h2 = plot( range_x, y2, '--g' );
   elseif (i==2) h3 = plot( range_x, y3, '--r' );
   end
   hold on
  end
    
    % --------- Set the other formats of the figure :  
    grid off  
    ylabel('reliability')  
    xlabel('number of controllers')  
      
    % --------- Plot the multi-legends :  
   
  
    ah1 = axes('position',get(gca,'position'), 'visible','off');    
  
    hg2 = legend(ah1, [h2,h3],  'CCPP', 'CMCPP',  0);  
    set(hg2,'FontSize',LegendFontSize);  
    % --------- Plot the multi-legends :~  
% --------- Set the other formats of the figure :~  