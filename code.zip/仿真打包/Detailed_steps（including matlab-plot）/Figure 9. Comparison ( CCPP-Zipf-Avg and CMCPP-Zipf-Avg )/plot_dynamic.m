clear;  

sum1= textread('ccpp-zipf-avg.txt','%d');
max1 = textread('cmcpp-zipf-avg.txt','%d');


range_x=0:1:70
figure  
    % ---------- Format of figure:  
    TextFontSize=18;  
    LegendFontSize = 16;  
    set(0,'DefaultAxesFontName','Times',...  
        'DefaultLineLineWidth',2,...  
        'DefaultLineMarkerSize',8);  
    set(gca,'FontName','Times New Roman','FontSize',TextFontSize);  
    set(gcf,'Units','inches','Position',[0 0 6.0 4.0]);  
    % ---------- Format of figure:~   
   
  for i=1:1:2
   s = hist(sum1,range_x)
   scdf = cumsum(s) / ( sum(s) );
   t = hist(max1,range_x)
   tcdf = cumsum(t) / ( sum(t) );
      if (i==1)   h1 = plot( range_x, scdf, '--r' );
      elseif (i==2) h2 = plot( range_x, tcdf, '-g' );
   end
   hold on
  end
   % --------- Set the other formats of the figure :  
    grid off  
    axis([0 70 0 1.0])  
    ylabel('fraction of topologies')  
    xlabel('required root controllers')  
      
    % --------- Plot the multi-legends :  
   
  
    ah1 = axes('position',get(gca,'position'), 'visible','off');    
   
    hg2 = legend(ah1, [h1,h2],  'CCPP-Zipf-Avg','CMCPP-Zipf-Avg',  0);  
	set(gcf,'color','w');
    set(hg2,'FontSize',LegendFontSize);  
    % --------- Plot the multi-legends :~  
% --------- Set the other formats of the figure :~  